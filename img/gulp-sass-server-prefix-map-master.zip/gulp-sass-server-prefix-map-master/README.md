# gulp-sass-server-prefix-map


NodeJS установить
https://nodejs.org/en/
npm i gulp-cli -g
https://gulpjs.com/
Прописать:
node -v
npm -v
gulp -v 

Далее
npm init -y 
Создали gulpfile.js
//sass+ browser-sync
npm i gulp browser-sync gulp-sass --save-dev

//sass + browser-sync + soursemap + autoprefix
npm i gulp browser-sync gulp-sass gulp-sourcemaps gulp-autoprefixer --save-dev

Создаем папки, организация рабочей области
